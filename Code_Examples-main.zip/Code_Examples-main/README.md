# Code_Examples
Compilation of Random Tests of Code I made
